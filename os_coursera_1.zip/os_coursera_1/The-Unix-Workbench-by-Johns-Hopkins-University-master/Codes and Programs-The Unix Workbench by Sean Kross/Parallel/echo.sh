#!/usr/bin/parallel --shebang -r echo
foo
bar
baz
