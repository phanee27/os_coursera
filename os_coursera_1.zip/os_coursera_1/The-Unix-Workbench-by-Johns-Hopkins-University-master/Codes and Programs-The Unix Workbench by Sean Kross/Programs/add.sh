#!/bin/bash
# File add.sh
first=20
second=1
sum=$((first + second))
echo "$sum"

