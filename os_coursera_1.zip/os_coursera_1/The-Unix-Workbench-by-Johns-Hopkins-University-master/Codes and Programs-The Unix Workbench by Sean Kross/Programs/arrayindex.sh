#!/bin/bash
# File: arrayindex.sh
array=(a ab abe abs abu ace ack act ada add ade)
echo "${array[$1]}"
