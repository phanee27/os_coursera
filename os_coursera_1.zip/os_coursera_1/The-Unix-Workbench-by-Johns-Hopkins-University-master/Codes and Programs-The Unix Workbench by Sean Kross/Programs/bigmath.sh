#!/bin/bash
# File: bigmath.sh

echo "22 / 7" | bc -l
echo "4.2 * 9.15" | bc -l
echo "( 6.5 / 0.5) + (6 * 2.2)" | bc -l
