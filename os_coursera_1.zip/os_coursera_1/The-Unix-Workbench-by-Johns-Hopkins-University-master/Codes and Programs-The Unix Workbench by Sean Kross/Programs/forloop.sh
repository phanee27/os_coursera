#!/bin/bash
# File: forloop.sh
echo "Before Loop"
for i in {1..3}
do
  echo "i is equal to $i"
done
echo "After Loop"
