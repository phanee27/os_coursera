#!/bin/bash
# File: hello.sh
function hello() {
  echo "Hello"
}

hello
hello
hello

