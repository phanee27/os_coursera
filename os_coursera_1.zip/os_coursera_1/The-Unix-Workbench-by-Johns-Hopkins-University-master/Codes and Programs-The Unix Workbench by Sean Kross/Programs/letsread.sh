#!/bin/bash
echo "Type in a string and then press
enter:"
IFS="" read -r response
echo "You entered: $response"

