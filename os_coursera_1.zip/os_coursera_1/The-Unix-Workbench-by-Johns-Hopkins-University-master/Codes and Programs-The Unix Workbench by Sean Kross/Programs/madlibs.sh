#!/bin/bash
echo "Type in an adjective and then
press enter:"
IFS="" read -r adjective
echo "Type in a noun and then press
enter:"
IFS="" read -r noun
echo "Type in a verb and then press
enter:"
IFS="" read -r verb
echo "$verb off with her $adjective
$noun."
