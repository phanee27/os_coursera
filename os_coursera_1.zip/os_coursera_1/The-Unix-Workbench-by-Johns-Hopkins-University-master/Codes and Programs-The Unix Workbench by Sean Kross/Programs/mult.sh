#!/bin/bash
# File mult.sh
input=$1
multiplier=100
echo $((input * multiplier))
