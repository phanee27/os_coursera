#!/bin/bash
# File: ntmy.sh
function ntmy() {
  echo "Nice to meet you, $1"
}
