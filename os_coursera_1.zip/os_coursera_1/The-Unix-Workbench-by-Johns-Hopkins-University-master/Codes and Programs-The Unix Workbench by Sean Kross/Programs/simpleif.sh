#!/bin/bash
# File: simpleif.sh
echo "Start program"

if [[ "$1" -eq 4 ]]
then
  echo "You entered $1"
fi

echo 'End program'
