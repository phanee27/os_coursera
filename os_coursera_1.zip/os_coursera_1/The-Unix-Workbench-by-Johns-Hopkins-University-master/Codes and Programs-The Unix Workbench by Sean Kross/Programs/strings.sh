#!/bin/bash
# File strings.sh
first='Hello, '
second='World!'
echo $first
echo $second
echo $first $second

