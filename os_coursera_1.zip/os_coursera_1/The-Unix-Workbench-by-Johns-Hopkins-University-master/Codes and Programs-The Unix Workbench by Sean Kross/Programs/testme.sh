#!/bin/bash

######################################################################
# @author      : $USER ($USER@localhost)
# @file        : testme
# @created     : Sunday Apr 28, 2019 02:16:24 IST
#
# @description :
######################################################################
#!/bin/bash
echo "This is Standard Output (stdout) and my parameters are \"$@\""
echo "This is Standard Error (stderr) and my parameters are \"$@\"" >&2
