#!/bin/bash
# File vars.sh

echo "Script arguments: $@"
echo "First argument $1. Second argument
$2."
echo "Number of arguments: $#."
