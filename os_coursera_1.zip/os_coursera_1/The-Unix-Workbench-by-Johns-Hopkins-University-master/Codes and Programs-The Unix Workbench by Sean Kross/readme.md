# Shell Scripts created for exercises in the book The Unix Workbench by Sean Kross

### Dir

- add.sh
- addseq.sh
- addseq2.sh
- arrayindex.sh
- bigmath.sh
- condexif.sh
- extremes.sh
- fib.sh
- fibconstant.sh
- fibrecursive.sh
- forloop.sh
- hello.sh
- howodd.sh
- ifloop.sh
- isiteven.sh
- letsread.sh
- madlibs.sh
- manyloops.sh
- math.sh
- mult.sh
- nested.sh
- nestedloops.sh
- nevens.sh
- ntmy.sh
- oddeven.sh
- plier.sh
- proper.sh
- simpleelif.sh
- simpleif.sh
- simpleifelse.sh
- strings.sh
- sumarray.sh
- sumstrings.sh
- tgif.sh
- vars.sh
- whileloop.sh
- wordcount.sh

### Dir Commands

- extremes
- range
- short
