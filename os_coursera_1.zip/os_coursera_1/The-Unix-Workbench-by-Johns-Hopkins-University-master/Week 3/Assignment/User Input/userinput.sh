#!/bin/bash

read adjective noun verb

echo $adjective $noun $verb


